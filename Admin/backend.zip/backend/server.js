import express from 'express';
import cors from 'cors';
import { NlpManager } from 'node-nlp';

const app = express();
app.use(cors());
app.use(express.json());

// --- 1. MOCK DATA (The Knowledge Base) ---
const RAIL_DATA = {
  traffic: [
    { station: "Dadar", level: "Critical", count: 4500 },
    { station: "Kurla", level: "High", count: 3200 },
    { station: "Churchgate", level: "Normal", count: 800 }
  ],
  sos: [
    { id: "SOS-991", type: "Medical", location: "Train C-12" }
  ]
};

// --- 2. TRAIN THE LOCAL MODEL ---
const manager = new NlpManager({ languages: ['en'], forceNER: true });

// Train: Navigation Intents
manager.addDocument('en', 'go to dashboard', 'nav.dashboard');
manager.addDocument('en', 'open home screen', 'nav.dashboard');
manager.addDocument('en', 'show me the dashboard', 'nav.dashboard');

manager.addDocument('en', 'show alerts', 'nav.alerts');
manager.addDocument('en', 'open warnings', 'nav.alerts');
manager.addDocument('en', 'any danger', 'nav.alerts');

manager.addDocument('en', 'check tickets', 'nav.tickets');
manager.addDocument('en', 'compliance status', 'nav.tickets');
manager.addDocument('en', 'ticket revenue', 'nav.tickets');

manager.addDocument('en', 'emergency', 'nav.sos');
manager.addDocument('en', 'help me', 'nav.sos');
manager.addDocument('en', 'open sos', 'nav.sos');

manager.addDocument('en', 'show cameras', 'nav.feed');
manager.addDocument('en', 'live video', 'nav.feed');
manager.addDocument('en', 'cctv', 'nav.feed');

// Train: Data Query Intents
manager.addDocument('en', 'how is the traffic', 'query.traffic');
manager.addDocument('en', 'where is the most crowd', 'query.traffic');
manager.addDocument('en', 'traffic status', 'query.traffic');

// Train: AI Responses (Generative-style)
manager.addAnswer('en', 'nav.dashboard', 'Navigating to the Main Dashboard.');
manager.addAnswer('en', 'nav.alerts', 'Opening the Alert Control Center.');
manager.addAnswer('en', 'nav.tickets', 'Switching to Compliance & Tickets view.');
manager.addAnswer('en', 'nav.sos', 'Opening Emergency SOS Dispatch immediately.');
manager.addAnswer('en', 'nav.feed', 'Connecting to Live CCTV Feeds.');
manager.addAnswer('en', 'query.traffic', 'DATA_HOOK:TRAFFIC'); // Special hook to insert real data

// Start Training
(async () => {
  console.log("🧠 Training Local AI Model...");
  await manager.train();
  manager.save();
  console.log("✅ AI Model Trained & Ready!");
})();

// --- 3. THE CHAT ENDPOINT ---
app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;
    
    // Process text with our local model
    const result = await manager.process('en', message);
    
    // Default response if the model is confused
    let reply = result.answer || "I'm not sure how to handle that command yet.";
    let action = "NONE";
    let target = null;

    // Handle Data Hooks (Dynamic Responses)
    if (reply === 'DATA_HOOK:TRAFFIC') {
        const critical = RAIL_DATA.traffic.find(t => t.level === "Critical");
        reply = `Traffic Analysis: ${critical.station} is currently Critical with ${critical.count} passengers. Kurla is High.`;
    }

    // Handle Navigation Actions
    if (result.intent === 'nav.dashboard') { action = "NAVIGATE"; target = "dashboard"; }
    if (result.intent === 'nav.alerts') { action = "NAVIGATE"; target = "alerts"; }
    if (result.intent === 'nav.tickets') { action = "NAVIGATE"; target = "tickets"; }
    if (result.intent === 'nav.sos') { action = "NAVIGATE"; target = "sos"; }
    if (result.intent === 'nav.feed') { action = "NAVIGATE"; target = "live_feed"; }

    res.json({ reply, action, target });

  } catch (error) {
    console.error(error);
    res.status(500).json({ reply: "Internal Brain Error." });
  }
});

app.listen(5000, () => console.log("🤖 Local RailBot Server running on 5000"));